﻿namespace CheckOrderStatus
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            dataGridView1 = new DataGridView();
            pictureBox1 = new PictureBox();
            ButtonShowOrderData = new Button();
            label3 = new Label();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(404, 55);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(541, 463);
            dataGridView1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(5, 142);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(396, 223);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // ButtonShowOrderData
            // 
            ButtonShowOrderData.BackColor = Color.White;
            ButtonShowOrderData.Font = new Font("맑은 고딕", 14F);
            ButtonShowOrderData.Location = new Point(59, 388);
            ButtonShowOrderData.Name = "ButtonShowOrderData";
            ButtonShowOrderData.Size = new Size(292, 78);
            ButtonShowOrderData.TabIndex = 2;
            ButtonShowOrderData.Text = "나의 주문현황 확인하기";
            ButtonShowOrderData.UseVisualStyleBackColor = false;
            ButtonShowOrderData.Click += ButtonShowOrderData_Click;
            // 
            // label3
            // 
            label3.BackColor = Color.Cyan;
            label3.Font = new Font("맑은 고딕", 16F);
            label3.Location = new Point(1, -1);
            label3.Name = "label3";
            label3.Size = new Size(956, 39);
            label3.TabIndex = 26;
            label3.Text = "주문현황 보기";
            label3.TextAlign = ContentAlignment.TopCenter;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(12, 55);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(155, 66);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 27;
            pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(955, 522);
            Controls.Add(pictureBox2);
            Controls.Add(label3);
            Controls.Add(ButtonShowOrderData);
            Controls.Add(pictureBox1);
            Controls.Add(dataGridView1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private PictureBox pictureBox1;
        private Button ButtonShowOrderData;
        private Label label3;
        private PictureBox pictureBox2;
    }
}
