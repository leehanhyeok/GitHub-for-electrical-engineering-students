using Oracle.ManagedDataAccess.Client;
using System.Data;

namespace carinfo
{
    public partial class Form1 : Form
    {
        private string connectionString = "User Id=scott;Password=tiger;" +
                                  "Data Source=(DESCRIPTION=" +
                                  "(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)" +
                                  "(HOST=192.168.0.2)(PORT=1521)))" +
                                  "(CONNECT_DATA=(SERVER=DEDICATED)" +
                                  "(SERVICE_NAME=xe)));";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string sh = @"C:\Users\Admin\Desktop\car\s_1.png";
            pictureBox1.Image = Image.FromFile(sh);
            string bh = @"C:\Users\Admin\Desktop\car\3_1.png";
            pictureBox2.Image = Image.FromFile(bh);
            string xh = @"C:\Users\Admin\Desktop\car\x_1.png";
            pictureBox3.Image = Image.FromFile(xh);
            string yh = @"C:\Users\Admin\Desktop\car\y_1.png";
            pictureBox4.Image = Image.FromFile(yh);
        }



        private void button1_Click(object sender, EventArgs e)
        {
            string selectedModel = comboBox1.SelectedItem?.ToString();
            string query = "";

            if (!string.IsNullOrEmpty(selectedModel))
            {
                // ���õ� �𵨿� ���� ���� �ۼ�
                switch (selectedModel)
                {
                    case "Model S":
                        query = "SELECT SORTATION, MODEL_S FROM CARINFO";
                        break;
                    case "Model 3":
                        query = "SELECT SORTATION, MODEL_3 FROM CARINFO";
                        break;
                    case "Model X":
                        query = "SELECT SORTATION, MODEL_X FROM CARINFO";
                        break;
                    case "Model Y":
                        query = "SELECT SORTATION, MODEL_Y FROM CARINFO";
                        break;
                }

                // ������ �����Ͽ� ������ �ε�
                LoadCarSpecifications(query);
            }
            else
            {
                MessageBox.Show("���� ���� ������ �ּ���.");
            }
        }
            private void LoadCarSpecifications(string query)
        {
            try
            {
                using (OracleConnection connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleDataAdapter adapter = new OracleDataAdapter(query, connection))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // DataGridView�� ������ ����
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("�����ͺ��̽����� ������ �ҷ����� ���� ������ �߻��߽��ϴ�: " + ex.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            {
                // �޺��ڽ� ������ �ٲ� ������ �̹����� ������Ʈ
                UpdateCarImages();
            }
        }
            private void UpdateCarImages()
            {
                // ComboBox���� ���õ� ���� ������
                string selectedModel = comboBox1.SelectedItem?.ToString();

                // ���õ� �𵨿� ���� �ش� PictureBox�� �̹��� ���� ��θ� ����
                switch (selectedModel)
                {
                    case "Model S":
                        pictureBox1.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\s.png");
                        pictureBox2.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\3_1.png");
                        pictureBox3.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\x_1.png");
                        pictureBox4.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\y_1.png");
                        break;
                    case "Model 3":
                        pictureBox1.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\s_1.png");
                        pictureBox2.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\3.png");
                        pictureBox3.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\x_1.png");
                        pictureBox4.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\y_1.png");
                        break;
                    case "Model X":
                        pictureBox1.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\s_1.png");
                        pictureBox2.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\3_1.png");
                        pictureBox3.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\x.png");
                        pictureBox4.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\y_1.png");
                        break;
                    case "Model Y":
                        pictureBox1.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\s_1.png");
                        pictureBox2.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\3_1.png");
                        pictureBox3.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\x_1.png");
                        pictureBox4.Image = Image.FromFile(@"C:\Users\Admin\Desktop\car\y.png");
                        break;
                }
            }
        }
}
