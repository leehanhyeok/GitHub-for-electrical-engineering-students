﻿namespace NumericApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            numericUpDownModel3 = new NumericUpDown();
            numericUpDownModelX = new NumericUpDown();
            numericUpDownModelY = new NumericUpDown();
            numericUpDownModelS = new NumericUpDown();
            ButtonOrder = new Button();
            listViewModelCar = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            groupBox1 = new GroupBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            groupBox2 = new GroupBox();
            ButtonAdd = new Button();
            ButtonDelete = new Button();
            ButtonClose = new Button();
            ((System.ComponentModel.ISupportInitialize)numericUpDownModel3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownModelX).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownModelY).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownModelS).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(223, 38);
            label2.Name = "label2";
            label2.Size = new Size(60, 25);
            label2.TabIndex = 3;
            label2.Text = "모델3";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(402, 38);
            label3.Name = "label3";
            label3.Size = new Size(59, 25);
            label3.TabIndex = 4;
            label3.Text = "모델x";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(576, 38);
            label4.Name = "label4";
            label4.Size = new Size(59, 25);
            label4.TabIndex = 5;
            label4.Text = "모델y";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(58, 38);
            label5.Name = "label5";
            label5.Size = new Size(58, 25);
            label5.TabIndex = 6;
            label5.Text = "모델s";
            // 
            // numericUpDownModel3
            // 
            numericUpDownModel3.Location = new Point(200, 251);
            numericUpDownModel3.Name = "numericUpDownModel3";
            numericUpDownModel3.Size = new Size(126, 33);
            numericUpDownModel3.TabIndex = 7;
            numericUpDownModel3.ValueChanged += numericUpDownModel3_ValueChanged;
            // 
            // numericUpDownModelX
            // 
            numericUpDownModelX.Location = new Point(384, 251);
            numericUpDownModelX.Name = "numericUpDownModelX";
            numericUpDownModelX.Size = new Size(126, 33);
            numericUpDownModelX.TabIndex = 8;
            // 
            // numericUpDownModelY
            // 
            numericUpDownModelY.Location = new Point(576, 251);
            numericUpDownModelY.Name = "numericUpDownModelY";
            numericUpDownModelY.Size = new Size(126, 33);
            numericUpDownModelY.TabIndex = 9;
            // 
            // numericUpDownModelS
            // 
            numericUpDownModelS.Location = new Point(17, 251);
            numericUpDownModelS.Name = "numericUpDownModelS";
            numericUpDownModelS.Size = new Size(126, 33);
            numericUpDownModelS.TabIndex = 10;
            // 
            // ButtonOrder
            // 
            ButtonOrder.Font = new Font("맑은 고딕", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            ButtonOrder.Location = new Point(791, 517);
            ButtonOrder.Name = "ButtonOrder";
            ButtonOrder.Size = new Size(135, 60);
            ButtonOrder.TabIndex = 11;
            ButtonOrder.Text = "주문 (db)";
            ButtonOrder.UseVisualStyleBackColor = true;
            ButtonOrder.Click += ButtonOrder_Click;
            // 
            // listViewModelCar
            // 
            listViewModelCar.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2 });
            listViewModelCar.Location = new Point(6, 22);
            listViewModelCar.Name = "listViewModelCar";
            listViewModelCar.Size = new Size(342, 395);
            listViewModelCar.TabIndex = 12;
            listViewModelCar.UseCompatibleStateImageBehavior = false;
            listViewModelCar.View = View.Details;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "모델명";
            columnHeader1.Width = 200;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "수량";
            columnHeader2.Width = 100;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ButtonHighlight;
            groupBox1.Controls.Add(pictureBox4);
            groupBox1.Controls.Add(pictureBox3);
            groupBox1.Controls.Add(pictureBox2);
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(numericUpDownModel3);
            groupBox1.Controls.Add(numericUpDownModelX);
            groupBox1.Controls.Add(numericUpDownModelS);
            groupBox1.Controls.Add(numericUpDownModelY);
            groupBox1.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            groupBox1.Location = new Point(23, 105);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(756, 370);
            groupBox1.TabIndex = 13;
            groupBox1.TabStop = false;
            groupBox1.Text = "모델 선택";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.테슬라_yy;
            pictureBox4.Location = new Point(576, 92);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(167, 96);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 14;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.테슬라_x;
            pictureBox3.Location = new Point(384, 92);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(167, 96);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 13;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.테슬라_333;
            pictureBox2.Location = new Point(200, 92);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(167, 96);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 12;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.테슬라_S;
            pictureBox1.Location = new Point(17, 92);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(167, 96);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(listViewModelCar);
            groupBox2.Font = new Font("맑은 고딕", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            groupBox2.Location = new Point(785, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(354, 423);
            groupBox2.TabIndex = 14;
            groupBox2.TabStop = false;
            groupBox2.Text = "장바구니";
            // 
            // ButtonAdd
            // 
            ButtonAdd.Font = new Font("맑은 고딕", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            ButtonAdd.Location = new Point(791, 441);
            ButtonAdd.Name = "ButtonAdd";
            ButtonAdd.Size = new Size(135, 60);
            ButtonAdd.TabIndex = 15;
            ButtonAdd.Text = "추가";
            ButtonAdd.UseVisualStyleBackColor = true;
            ButtonAdd.Click += ButtonAdd_Click;
            // 
            // ButtonDelete
            // 
            ButtonDelete.Font = new Font("맑은 고딕", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            ButtonDelete.Location = new Point(998, 441);
            ButtonDelete.Name = "ButtonDelete";
            ButtonDelete.Size = new Size(135, 60);
            ButtonDelete.TabIndex = 16;
            ButtonDelete.Text = "제거";
            ButtonDelete.UseVisualStyleBackColor = true;
            ButtonDelete.Click += ButtonDelete_Click;
            // 
            // ButtonClose
            // 
            ButtonClose.Font = new Font("맑은 고딕", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 129);
            ButtonClose.Location = new Point(998, 517);
            ButtonClose.Name = "ButtonClose";
            ButtonClose.Size = new Size(135, 60);
            ButtonClose.TabIndex = 17;
            ButtonClose.Text = "종료";
            ButtonClose.UseVisualStyleBackColor = true;
            ButtonClose.Click += ButtonClose_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1142, 589);
            Controls.Add(ButtonClose);
            Controls.Add(ButtonDelete);
            Controls.Add(ButtonAdd);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(ButtonOrder);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)numericUpDownModel3).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownModelX).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownModelY).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownModelS).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private NumericUpDown numericUpDownModel3;
        private NumericUpDown numericUpDownModelX;
        private NumericUpDown numericUpDownModelY;
        private NumericUpDown numericUpDownModelS;
        private Button ButtonOrder;
        private ListView listViewModelCar;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Button ButtonAdd;
        private Button ButtonDelete;
        private Button ButtonClose;
        private PictureBox pictureBox1;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
    }
}
